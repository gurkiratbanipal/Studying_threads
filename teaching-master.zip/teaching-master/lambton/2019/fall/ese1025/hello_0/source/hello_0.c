/*
 ============================================================================
 Name        : hello_0.c
 Author      : takis
 Version     :
 Copyright   : (c) 2019 emad studio inc.
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>

int main()
{
	printf("Hello, from Lambton College in Toronto!\n"); /* greeting sent to console */
	return 0;
}
